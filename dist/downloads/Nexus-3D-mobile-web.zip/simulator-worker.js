/* Generated with the production simulator's exact static dependencies. */
const prefix = 'nexus-3d-flight-';
const cacheName = prefix + '939052b862f587d96f43';
const files = {"/assets/ChallengesView-DTCpcTi5.js":"sha256-lMtxoGkPOKspiHhL7zepvUQGJTVDXnMyXsLySZ+FMAI=","/assets/DroneGarage-BQULUX4R.js":"sha256-ZdaegQ8D+oD5ZimHSyO4loLvXwhciLQIjrwWWpCTDMU=","/assets/DroneGarage-CHLdF3iJ.css":"sha256-+hFmvn7q6MelBAsusJ/CrOLAPs/b8q81E92G68WL7Ps=","/assets/EnvironmentControls-BvRSR0za.js":"sha256-XdMMyuHCnOF0zwTiPdotDR+TIFY2XN4KBY0NGiQt700=","/assets/EnvironmentControls-UL3s84HF.css":"sha256-coVTDYIlWDGqRQ79zbgEKTtyptT2bZaFFjJFweMawtY=","/assets/OrbitControls-CVNbhNwJ.js":"sha256-7U0TEomalyBOlGbi9LBx1Nq7Ca5Ybj3Qj+pN6q4NFfQ=","/assets/PageHeader-BNasAuxQ.js":"sha256-FFcPtrcSYjOYDaS1k9N1jvZKW8bTAAqJfF2z9vv5Zi8=","/assets/SimulatorPage-CaoW1WGE.css":"sha256-antnYI6R4yhZCfd4Pt8VeL97v1PNF79XPZbC1MPVYq0=","/assets/SimulatorPage-DuKghAQ7.js":"sha256-xiuX12oNsoLmo+6UpTXBL/29bqL3v31jTJfk7x4OTbo=","/assets/SoundControls-BMbVNxRQ.js":"sha256-/Zu/9dMJdF97PU4siUWnWJJd2J30kn6HzYAq1HsbO4E=","/assets/challenges-axyPcjSx.js":"sha256-2y/NuEWsZlPJw2Vs59wLILuD8Yyt1SI116FlaAK4D48=","/assets/commands-C3adrRo0.js":"sha256-IdWUwJyqgTzaXz1cGsu7w52OOqACbvBy3LN2NfCjMj8=","/assets/droneModels-EDF7NcBt.js":"sha256-0oc+VpbQassqzvjuA3ec95GzcO8Zi0SH1YjMtGSYtRo=","/assets/index-B-t9WTl-.css":"sha256-5GkSm99kOERHhA8pxPpiO08taUxKH6CLrGzrkVAL7do=","/assets/index-BtqsOdQl.js":"sha256-vZQKc6btpdiMR2RsSGV6K2ottvo7hhBhj0Kz03bHzho=","/assets/jsx-runtime-Dk72oS4N.js":"sha256-xfT42gA45Agq/ABUL5OqG7ZLxXd4AdZxl1B4ZZFaibY=","/assets/localAirspace-V4QPmhSl.js":"sha256-uA9+6wRhPzdq6dSBgCuraoVwLsLTKY3pB7wCmrU5U1k=","/assets/localId-DndsePE2.js":"sha256-3X2LeKzU4Pmax7bSjjYE6QAE6/a2qsucaP61XGI+dPo=","/assets/middleware-CevThqKp.js":"sha256-ZWeshqEsmueNQHMv0nWOuA9IjqSSiYPm9/sfCaA+ihk=","/assets/payload-BDYWwDdX.js":"sha256-ni6+ykiUL+b3nKpoxLqcwiXSNfiC7vLt2WqD9GadBho=","/assets/react-HmBgu_x6.js":"sha256-MfE3ekXm25z4xIJfya4/i7UvE1V0TLEuC0Yg/xxBY4g=","/assets/simulator-B289B5P8.js":"sha256-mKvTlM8ChUTb3t4tnqHupz1EOVEp2sPe6U5t7YP6reU=","/assets/useTelemetryHealth-DTfmcr-O.js":"sha256-1xdjBH2koHTxjTyqXZZuv3/imqY2b7um53xEENBsuJM=","/favicon.svg":"sha256-YbyaFh3lgkgojmkFQl1xgPBiTChlAHuX12P9rBIEOmY=","/index.html":"sha256-EtIEjaOvoUPsKB1KsoNhSN2yjbRNjWtWrEvdfuBQyrs=","/simulator-pwa/flight.webmanifest":"sha256-lIYZ2f2UtfXlHlglmy2+/QeRjYQKBJWqBvo/wWMfCJA=","/simulator-pwa/icon-192.png":"sha256-e02Y3Fjj1bSbYYRGAJdfAyIYwgSnWorY9YZkJuUJ9co=","/simulator-pwa/icon-512.png":"sha256-+GI9UuLySTwA6J2fystPUucJ3s04syJbnXAuMJ2u8Dg=","/simulator-pwa/maskable-512.png":"sha256-85lJ3f4CExuw5toKaljpOv0WDCeSL1B72srSGxwL3V0="};
const routes = new Set(["/simulator","/garage","/challenges"]);
self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(cacheName);
    // addAll commits atomically. An auth redirect or partial deploy fails integrity.
    const requests = Object.entries(files).map(([path, integrity]) =>
      new Request(new URL(path, self.location.origin), { integrity, cache: 'reload', redirect: 'error', credentials: 'omit' }));
    await cache.addAll(requests);
  })());
});
self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    for (const key of await caches.keys()) {
      if (key.startsWith(prefix) && key !== cacheName) await caches.delete(key);
    }
    await self.clients.claim();
  })());
});
self.addEventListener('fetch', event => {
  const { request } = event;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin) return;
  const isGamePage = url => routes.has(url.pathname) && url.searchParams.get('launch') !== 'live';
  let key = url.pathname;
  if (request.mode === 'navigate') {
    if (!isGamePage(url)) return;
    key = '/index.html';
  } else if (url.search || !Object.hasOwn(files, key)) return;
  event.respondWith((async () => {
    if (request.mode !== 'navigate') {
      const client = event.clientId && await self.clients.get(event.clientId);
      if (!client || !isGamePage(new URL(client.url))) return fetch(request);
    }
    const cache = await caches.open(cacheName);
    return (await cache.match(new URL(key, self.location.origin).href)) || fetch(request);
  })());
});

/* Generated with the production simulator's exact static dependencies. */
const prefix = 'nexus-3d-flight-';
const cacheName = prefix + 'c1e2544f5cbda1306d43';
const files = {"/assets/ChallengesView-cin9AhFN.js":"sha256-6hjpJkg+tKORBbIB4OKvaaSNjbfNRYsvn00bLMaWJcQ=","/assets/DroneGarage-CHLdF3iJ.css":"sha256-+hFmvn7q6MelBAsusJ/CrOLAPs/b8q81E92G68WL7Ps=","/assets/DroneGarage-NJ20eEl-.js":"sha256-+q14ZwhSh5/9BBiSdYR6nW2UDa9cTf3RRNlzikOFheA=","/assets/EnvironmentControls-BiZX5Oif.js":"sha256-Xd+1AJD/5G6yPc4zrFD5WtYzN0dQegZlsad1czbkwvY=","/assets/EnvironmentControls-UL3s84HF.css":"sha256-coVTDYIlWDGqRQ79zbgEKTtyptT2bZaFFjJFweMawtY=","/assets/OrbitControls-CVNbhNwJ.js":"sha256-7U0TEomalyBOlGbi9LBx1Nq7Ca5Ybj3Qj+pN6q4NFfQ=","/assets/PageHeader-DfJVpZy8.js":"sha256-trddZ61G88+YURzl7wLwHI7Zu90vWoP+v1qM7WdzeTc=","/assets/SimulatorPage-C0yi2uLQ.css":"sha256-6rtxJQ7r5eueSl28076wGgo7CDFkyRHRqInXFyrxPQw=","/assets/SimulatorPage-oV-iR7hv.js":"sha256-aJQ7YG77hGNU9OBER+Y+Cj0joXi63pvQOu5fEX+ULb0=","/assets/SoundControls-Drq3AcPr.js":"sha256-rGBVxW+OGR5nVhetLXKZWLNVGovay3a9eDsiunnKZ5c=","/assets/challenges-axyPcjSx.js":"sha256-2y/NuEWsZlPJw2Vs59wLILuD8Yyt1SI116FlaAK4D48=","/assets/commands-C3adrRo0.js":"sha256-IdWUwJyqgTzaXz1cGsu7w52OOqACbvBy3LN2NfCjMj8=","/assets/droneModels-EDF7NcBt.js":"sha256-0oc+VpbQassqzvjuA3ec95GzcO8Zi0SH1YjMtGSYtRo=","/assets/index-BSMHM-j7.js":"sha256-hSJDf/SMxl4eR6o6FZrJM/Cdp5G7G8Fm+K0ZhbUeIqw=","/assets/index-D21krT8E.css":"sha256-l+oPoKlmcO0ix0cI+Vc25OBsJPPnevRzvqe+PckMNPs=","/assets/jsx-runtime-Dk72oS4N.js":"sha256-xfT42gA45Agq/ABUL5OqG7ZLxXd4AdZxl1B4ZZFaibY=","/assets/localAirspace-V4QPmhSl.js":"sha256-uA9+6wRhPzdq6dSBgCuraoVwLsLTKY3pB7wCmrU5U1k=","/assets/localId-DndsePE2.js":"sha256-3X2LeKzU4Pmax7bSjjYE6QAE6/a2qsucaP61XGI+dPo=","/assets/middleware-CevThqKp.js":"sha256-ZWeshqEsmueNQHMv0nWOuA9IjqSSiYPm9/sfCaA+ihk=","/assets/payload-BDYWwDdX.js":"sha256-ni6+ykiUL+b3nKpoxLqcwiXSNfiC7vLt2WqD9GadBho=","/assets/react-HmBgu_x6.js":"sha256-MfE3ekXm25z4xIJfya4/i7UvE1V0TLEuC0Yg/xxBY4g=","/assets/simulator-B289B5P8.js":"sha256-mKvTlM8ChUTb3t4tnqHupz1EOVEp2sPe6U5t7YP6reU=","/assets/useTelemetryHealth-CojCJYxl.js":"sha256-nnaLbc1p9cKpBnfcMVJtINvi629iVv6iYt5md1SQt0g=","/favicon.svg":"sha256-YbyaFh3lgkgojmkFQl1xgPBiTChlAHuX12P9rBIEOmY=","/simulator-pwa/flight.webmanifest":"sha256-pMABe/PmblNNxBiQbGTLxHvsVQNim2/LlTb3w0MPu68=","/simulator-pwa/icon-192.png":"sha256-e02Y3Fjj1bSbYYRGAJdfAyIYwgSnWorY9YZkJuUJ9co=","/simulator-pwa/icon-512.png":"sha256-+GI9UuLySTwA6J2fystPUucJ3s04syJbnXAuMJ2u8Dg=","/simulator-pwa/maskable-512.png":"sha256-85lJ3f4CExuw5toKaljpOv0WDCeSL1B72srSGxwL3V0="};
const routes = new Set(["/simulator","/garage","/challenges"]);
// Static hosts can redirect index.html or personalize online navigation. Keep
// the build's offline document with the worker and never persist a login page.
const offlineHtml = "<!doctype html>\n<html lang=\"en\">\n  <head>\n    <meta charset=\"UTF-8\" />\n    <link rel=\"icon\" type=\"image/svg+xml\" href=\"/favicon.svg\" />\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, viewport-fit=cover\" />\n    <title>Nexus Flight Simulator</title>\n    <meta name=\"description\" content=\"Browser ground control station and interactive offline drone flight simulator.\" />\n    <script type=\"module\" crossorigin src=\"/assets/index-BSMHM-j7.js\"></script>\n    <link rel=\"modulepreload\" crossorigin href=\"/assets/jsx-runtime-Dk72oS4N.js\">\n    <link rel=\"modulepreload\" crossorigin href=\"/assets/react-HmBgu_x6.js\">\n    <link rel=\"modulepreload\" crossorigin href=\"/assets/commands-C3adrRo0.js\">\n    <link rel=\"stylesheet\" crossorigin href=\"/assets/index-D21krT8E.css\">\n  </head>\n  <body>\n    <div id=\"root\"></div>\n  </body>\n</html>\n";
async function download() {
    const cache = await caches.open(cacheName);
    // addAll commits atomically. An auth redirect or partial deploy fails integrity.
    const requests = Object.entries(files).map(([path, integrity]) =>
      new Request(new URL(path, self.location.origin), { integrity, cache: 'reload', redirect: 'error', credentials: 'same-origin' }));
    await cache.addAll(requests);
}
self.addEventListener('install', event => event.waitUntil(download()));
self.addEventListener('message', event => {
  const reply = event.ports[0];
  if (!reply || !event.source?.url) return;
  const source = new URL(event.source.url);
  if (source.origin !== self.location.origin || source.pathname.replace(/\/$/, '') !== '/simulator') return;
  event.waitUntil((async () => {
    try {
      if (event.data === 'ACTIVATE') {
        const tabs = await self.clients.matchAll({type: 'window', includeUncontrolled: true});
        if (tabs.some(tab => tab.id !== event.source.id)) {
          reply.postMessage('OTHER_TABS');
          return;
        }
        await self.skipWaiting();
        reply.postMessage('ACTIVATING');
        return;
      }
      if (event.data !== 'CHECK' && event.data !== 'REPAIR') return;
      if (event.data === 'REPAIR') await download();
      const cache = await caches.open(cacheName);
      const saved = new Set((await cache.keys()).map(request => request.url));
      const complete = Object.keys(files).every(path => saved.has(new URL(path, self.location.origin).href));
      reply.postMessage(complete ? 'COMPLETE' : 'INCOMPLETE');
    } catch {
      reply.postMessage('FAILED');
    }
  })());
});
self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    for (const key of await caches.keys()) {
      if (key.startsWith(prefix) && key !== cacheName) await caches.delete(key);
    }
    await self.clients.claim();
  })());
});
self.addEventListener('fetch', event => {
  const { request } = event;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin) return;
  const isGamePage = url => routes.has(url.pathname.replace(/\/$/, '')) && url.searchParams.get('launch') !== 'live';
  const key = url.pathname;
  if (request.mode === 'navigate') {
    if (!isGamePage(url)) return;
  } else if (url.search || !Object.hasOwn(files, key)) return;
  event.respondWith((async () => {
    if (request.mode === 'navigate') {
      // An online launch must pass through the host's normal access checks.
      try { return await fetch(request); } catch {
        return new Response(offlineHtml, { headers: {
          'Content-Type': 'text/html; charset=utf-8',
          'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'none'"
        } });
      }
    } else {
      const client = event.clientId && await self.clients.get(event.clientId);
      if (!client || !isGamePage(new URL(client.url))) return fetch(request);
    }
    const cache = await caches.open(cacheName);
    return (await cache.match(new URL(key, self.location.origin).href)) || fetch(request);
  })());
});

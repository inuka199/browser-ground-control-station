/* Generated with the production simulator's exact static dependencies. */
const prefix = 'nexus-3d-flight-';
const cacheName = prefix + '0e5cd71b79b822272ea5';
const files = {"/assets/ChallengesView-c3RnlVfa.js":"sha256-HDoXlwNfYkScV8A6DFFPziWJTzWnBKhMqjeg8jCM3MM=","/assets/DroneGarage-2HXrY3oZ.js":"sha256-gXWBYiscb4P6xw7wPEKLc9c+fEXsNg5/m8PDO8vLlSA=","/assets/DroneGarage-CHLdF3iJ.css":"sha256-+hFmvn7q6MelBAsusJ/CrOLAPs/b8q81E92G68WL7Ps=","/assets/EnvironmentControls-BiZX5Oif.js":"sha256-Xd+1AJD/5G6yPc4zrFD5WtYzN0dQegZlsad1czbkwvY=","/assets/EnvironmentControls-UL3s84HF.css":"sha256-coVTDYIlWDGqRQ79zbgEKTtyptT2bZaFFjJFweMawtY=","/assets/OrbitControls-CVNbhNwJ.js":"sha256-7U0TEomalyBOlGbi9LBx1Nq7Ca5Ybj3Qj+pN6q4NFfQ=","/assets/PageHeader-Cm7khxCA.js":"sha256-SNS7EHuAeKHa+SmwCW+yZCtTkdRbNiOrB4+obRv4gzA=","/assets/SimulatorPage-Cqsb6czJ.js":"sha256-4napTQHZrNYFdiH7CDCSQZ4cwxGbS4bQ28vvQvOmkF8=","/assets/SimulatorPage-Deb5BUhY.css":"sha256-xfhnzjhbny1DUkdDUaHv0vd12BJsSeUJenR0u8YZTuo=","/assets/SoundControls-Drq3AcPr.js":"sha256-rGBVxW+OGR5nVhetLXKZWLNVGovay3a9eDsiunnKZ5c=","/assets/challenges-axyPcjSx.js":"sha256-2y/NuEWsZlPJw2Vs59wLILuD8Yyt1SI116FlaAK4D48=","/assets/commands-C3adrRo0.js":"sha256-IdWUwJyqgTzaXz1cGsu7w52OOqACbvBy3LN2NfCjMj8=","/assets/droneModels-EDF7NcBt.js":"sha256-0oc+VpbQassqzvjuA3ec95GzcO8Zi0SH1YjMtGSYtRo=","/assets/index-D21krT8E.css":"sha256-l+oPoKlmcO0ix0cI+Vc25OBsJPPnevRzvqe+PckMNPs=","/assets/index-DRCjzeA9.js":"sha256-cdk52/cPe6MJB8uvRSai7XFEFXLvGtCuMTTWwv6W5ic=","/assets/jsx-runtime-Dk72oS4N.js":"sha256-xfT42gA45Agq/ABUL5OqG7ZLxXd4AdZxl1B4ZZFaibY=","/assets/localAirspace-V4QPmhSl.js":"sha256-uA9+6wRhPzdq6dSBgCuraoVwLsLTKY3pB7wCmrU5U1k=","/assets/localId-DndsePE2.js":"sha256-3X2LeKzU4Pmax7bSjjYE6QAE6/a2qsucaP61XGI+dPo=","/assets/middleware-CevThqKp.js":"sha256-ZWeshqEsmueNQHMv0nWOuA9IjqSSiYPm9/sfCaA+ihk=","/assets/payload-BDYWwDdX.js":"sha256-ni6+ykiUL+b3nKpoxLqcwiXSNfiC7vLt2WqD9GadBho=","/assets/react-HmBgu_x6.js":"sha256-MfE3ekXm25z4xIJfya4/i7UvE1V0TLEuC0Yg/xxBY4g=","/assets/simulator-B289B5P8.js":"sha256-mKvTlM8ChUTb3t4tnqHupz1EOVEp2sPe6U5t7YP6reU=","/assets/useTelemetryHealth-Bx2Rlil-.js":"sha256-l3mtB2Uo7+yWoUgyS2V/WtnUKNFNzcXP0us/6bmDFFw=","/favicon.svg":"sha256-YbyaFh3lgkgojmkFQl1xgPBiTChlAHuX12P9rBIEOmY=","/index.html":"sha256-F/JrzcARHWce6xAHgWgyQSGO7Dq2Jx2EUzzI0PfNRag=","/simulator-pwa/flight.webmanifest":"sha256-lIYZ2f2UtfXlHlglmy2+/QeRjYQKBJWqBvo/wWMfCJA=","/simulator-pwa/icon-192.png":"sha256-e02Y3Fjj1bSbYYRGAJdfAyIYwgSnWorY9YZkJuUJ9co=","/simulator-pwa/icon-512.png":"sha256-+GI9UuLySTwA6J2fystPUucJ3s04syJbnXAuMJ2u8Dg=","/simulator-pwa/maskable-512.png":"sha256-85lJ3f4CExuw5toKaljpOv0WDCeSL1B72srSGxwL3V0="};
const routes = new Set(["/simulator","/garage","/challenges"]);
self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(cacheName);
    // addAll commits atomically. An auth redirect or partial deploy fails integrity.
    const requests = Object.entries(files).map(([path, integrity]) =>
      new Request(new URL(path, self.location.origin), { integrity, cache: 'reload', redirect: 'error', credentials: 'omit' }));
    await cache.addAll(requests);
  })());
});
self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    for (const key of await caches.keys()) {
      if (key.startsWith(prefix) && key !== cacheName) await caches.delete(key);
    }
    await self.clients.claim();
  })());
});
self.addEventListener('fetch', event => {
  const { request } = event;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin) return;
  const isGamePage = url => routes.has(url.pathname) && url.searchParams.get('launch') !== 'live';
  let key = url.pathname;
  if (request.mode === 'navigate') {
    if (!isGamePage(url)) return;
    key = '/index.html';
  } else if (url.search || !Object.hasOwn(files, key)) return;
  event.respondWith((async () => {
    if (request.mode !== 'navigate') {
      const client = event.clientId && await self.clients.get(event.clientId);
      if (!client || !isGamePage(new URL(client.url))) return fetch(request);
    }
    const cache = await caches.open(cacheName);
    return (await cache.match(new URL(key, self.location.origin).href)) || fetch(request);
  })());
});
